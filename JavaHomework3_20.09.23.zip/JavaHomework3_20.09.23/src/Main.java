import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
     Random rnd = new Random();
     int[] array = new int[8];
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1,51);
            System.out.println(array[i]);
        }
        System.out.println("Next one");
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1,51);
            if (i % 2 !=0){
                array[i] = 0;
            }
            System.out.println(array[i]);
        }
        System.out.println("Another one");
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1,51);
        }
        Arrays.sort(array);
        for (int ar:array) {
            System.out.println(ar);
        }
    }
}