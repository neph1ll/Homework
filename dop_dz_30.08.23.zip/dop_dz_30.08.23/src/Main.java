public class Main {
    public static void main(String[] args) {
        int a = 5;
        double c = 5.5;
        System.out.println(a*c);

        char v = '2';
        System.out.println(v);
        v = v+1;
        System.out.println(v);


    }
}