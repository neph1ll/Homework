import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println(" Введите первое слово ");
        String str1 = new Scanner(System.in).nextLine();
        System.out.println(" Введите второе слово ");
        String str2 = new Scanner(System.in).nextLine();
        String str3 = (str1.substring(0, str1.length() / 2)) +
                (str2.substring(str2.length() / 2, str2.length()));
        System.out.println(str3);
    }
}