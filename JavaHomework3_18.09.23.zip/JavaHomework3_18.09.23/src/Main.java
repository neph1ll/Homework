import bebebe.DaysOfWeek;

import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Напиши любой день недели: ");
        String day = scr.nextLine();
        System.out.println("Все остальные деньки: ");
        for (DaysOfWeek d : DaysOfWeek.values()) {
            if (Objects.equals(day, "Monday")) {
                if (d.equals(DaysOfWeek.MONDAY)) continue;
                System.out.println(d);
            } else if (Objects.equals(day, "Tuesday")) {
                if (d.equals(DaysOfWeek.TUESDAY)) continue;
                System.out.println(d);
            } else if (Objects.equals(day, "Wednesday")) {
                if (d.equals(DaysOfWeek.WEDNESDAY)) continue;
                System.out.println(d);
            } else if (Objects.equals(day, "Thursday")) {
                if (d.equals(DaysOfWeek.THURSDAY)) continue;
                System.out.println(d);
            } else if (Objects.equals(day, "Friday")) {
                if (d.equals(DaysOfWeek.FRIDAY)) continue;
                System.out.println(d);
            } else if (Objects.equals(day, "Saturday")) {
                if (d.equals(DaysOfWeek.SATURDAY)) continue;
                System.out.println(d);
            } else if (Objects.equals(day, "Sunday")) {
                if (d.equals(DaysOfWeek.SUNDAY)) continue;
                System.out.println(d);
            } else {
                System.out.println("Дебил");
            }
        }
    }
}
