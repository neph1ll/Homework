import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt();
        short s = (short) rnd.nextInt();
        int i = rnd.nextInt();
        long l = rnd.nextLong();
        float f = rnd.nextFloat();
        double d = rnd.nextDouble();
        boolean boo = rnd.nextBoolean();
        char c = (char) rnd.nextInt();

        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
        System.out.println(boo);
        System.out.println(c);


        int i2 = rnd.nextInt();
        String str = String.valueOf(i2);
        System.out.println(str);


    }
}