import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner sqr = new Scanner(System.in);
        System.out.println("Привет, я хочу проверить твои знания в области таблицы умножения");
        System.out.print("Введи 1 целое число: ");
        int num1 = sqr.nextInt();
        System.out.print("Хорошо, теперь введи 2 целое число: ");
        int num2 = sqr.nextInt();
        System.out.print("Замечательно, теперь введите ответ:");
        int res1 = sqr.nextInt();
        int res2 = num1*num2;
        if (res1==res2){
            System.out.println("Какой ты молодец, ответ правильный!");
        }
        else {
            System.out.println("Быть может ты ошибся? Правильный ответ: " + res2);
        }




    }
}