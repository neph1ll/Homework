import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner sqr = new Scanner(System.in);
        System.out.print("Введите целое число: ");
        int i = sqr.nextInt();
        System.out.println(i>>1);
    }
}