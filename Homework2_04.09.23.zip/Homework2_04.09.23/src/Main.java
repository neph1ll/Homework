import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Доброго времени суток, введите ваше имя: ");
        String name = scanner.nextLine();
        System.out.print(name + ", " + "сколько вам лет? ");
        int age = scanner.nextInt();
        System.out.print("Скажите пожалуйста, какой у вас вес? ");
        String weigh = scanner.nextLine();
        weigh = scanner.nextLine();
        System.out.println("Замечательно");
        System.out.println("Уважаемые " + name + ", " + "в свои " + age + " лет. Вы для нас дороги, как " + weigh + " киллограм чистого золота!!!");


    }
}