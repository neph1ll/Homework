import java.util.Scanner;

public class MyProject {
    public static void main(String[] args) {
        System.out.println(2 + 2);
        Scanner VanyaScanner = new Scanner(System.in);
        String a = VanyaScanner.nextLine();
        System.out.println(a);

    }
}