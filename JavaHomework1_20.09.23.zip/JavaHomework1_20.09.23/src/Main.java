import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введи 1 целое число");
        int num1 = scr.nextInt();
        System.out.println("Введи 2 целое число");
        int num2 = scr.nextInt();
        System.out.println(getMulti(num1, num2));
        System.out.println("Введи 3 целое число");
        int num3 = scr.nextInt();
        System.out.println(getMulti(num1, num2, num3));
        System.out.println("Введи 4 целое число");
        int num4 = scr.nextInt();
        System.out.println(getMulti(num1, num2, num3 ,num4));
    }

    private static int getMulti(int num1, int num2) {
        int result = num1 * num2;
        return result;
    }
    private static int getMulti(int num1, int num2, int num3){
        int result = num1 * num2 * num3;
        return result;
    }
    private static int getMulti(int num1, int num2, int num3, int num4){
        int result = num1 * num2 * num3 * num4;
        return result;
    }


}