public class Main {
    public static void main(String[] args) {
        long masha= 987654321;
        long oleg= 123456789;
        long summa= oleg + masha;
        System.out.println("Сумма Яблок = " + summa);
    }
}