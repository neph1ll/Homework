import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner sqr = new Scanner(System.in);
        System.out.print("Привет, введи какой-нибудь год в промежутке 1900-2000: ");
        int year = sqr.nextInt();
        System.out.print(year >= 1935 && year <=1977 ? "Элвис жив!" : "");
        System.out.print(year < 1935 ? "Элвис ещё не родился" : "");
        System.out.print(year > 1977 ? "Элвис навсегда в наших сердцах!" : "");
    }
}