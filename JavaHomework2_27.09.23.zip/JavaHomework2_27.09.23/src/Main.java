
import java.util.Locale;

    public class Main {
        public static void main(String[] args) {
            String str = new String("Im study Java!");
            makeString(str);
        }

        public static void makeString(String s){
            System.out.println(s.charAt(s.length()-1));
            System.out.println(s.contains("Java"));
            System.out.println(s.replace("a", "o"));
            System.out.println(s.toUpperCase(Locale.ROOT));
            System.out.println(s.toLowerCase(Locale.ROOT));
            System.out.println(s.substring(9,13));

        }
    }