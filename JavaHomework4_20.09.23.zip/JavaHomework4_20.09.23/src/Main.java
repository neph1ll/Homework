public class Main {
    public static void main(String[] args) {
    String[] str = {
            "Be", "Byaka", "Byukaa", "Asshole", "F"
    };
    String min = str[0];
    String max = str[0];
        for (int i = 1; i < str.length; i++) {
            if (min.length() > str[i].length()){
                min = str[i];
            }
           if (max.length() < str[i].length()){
               max = str[i];
           }
        }
        System.out.println(min);
        System.out.println(max);
    }
}