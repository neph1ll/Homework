import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введи число: ");
        Scanner scr = new Scanner(System.in);
        int n = scr.nextInt();
        System.out.println("Факториал введённого числа: " + calculateFactorial(n));
    }

    public static int calculateFactorial(int n) {
        int result = 1;
        for (int i = 1; i <= n; i++) {
            result = result * i;
        }
        return result;
    }
}





