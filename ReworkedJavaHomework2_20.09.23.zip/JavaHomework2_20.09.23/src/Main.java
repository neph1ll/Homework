import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введи число: ");
        Scanner scr = new Scanner(System.in);
        int n = scr.nextInt();
        System.out.println("Факториал введённого числа: " + calculateFactorial(n));
    }

    public static int calculateFactorial(int n) {
        int result = 1;
        if (n == 0){
            return result;
        }
        result = n*(calculateFactorial(n-1));
        return result;
    }
}





