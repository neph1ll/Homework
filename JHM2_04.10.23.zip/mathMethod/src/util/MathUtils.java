package util;

import java.util.Arrays;

public class MathUtils {
    private MathUtils() {
    }

    public static double addAll(double... v) {

        return Arrays.stream(v).sum();
    }

    public static double minusAll(double source, double... v) {
        for (double oneFromV : v) {
            source -= oneFromV;
        }
        return source;
    }

    public static double multAll(double... v) {
        double result = 1;
        for (double oneFromV : v) {
            result *= oneFromV;
        }
        return result;
    }

    private static double pow(double value, int powValue) {
        if (powValue == 0) {
            return 1;
        }
        double result = 1;
        int absExponent = powValue > 0 ? powValue : -powValue;

        for (int i = 0; i < absExponent; i++) {
            result *= value;
        }
        return powValue > 0 ? result : 1 / result;
    }

    public static double powAll(double source, double... v) {
        double result = source;
        for (double oneFromV : v) {
            result = pow(result, (int) oneFromV);
        }
        return result;
    }
}

