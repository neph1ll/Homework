import util.MathUtils;

public class Main {
    public static void main(String[] args) {
        System.out.println("Addition: ");
        System.out.println(MathUtils.addAll(2.6, 4, 2));
        System.out.println("Subtraction: ");
        System.out.println(MathUtils.minusAll(200, 50, 34.5, 16.5));
        System.out.println("Multiplication: ");
        System.out.println(MathUtils.multAll(4,8,1));
        System.out.println("возведения в степень: ");
        System.out.println(MathUtils.powAll(4,4,4));
    }
}
