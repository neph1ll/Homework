import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введи 1 целое число: ");
        int num1 = scanner.nextInt();
        System.out.println("Введи 2 целое число: ");
        int num2 = scanner.nextInt();scanner.nextLine();
        int sum = 0;
        String str = "";
        do {
            for (int i = num1; i <= num2; i++) {
                if (i % 2 != 0) {
                    sum += i;
                }
            }
            System.out.println(sum);
            System.out.println("Введи \"quit\" для выхода");
            str = scanner.nextLine();
        }while (!"quit".equalsIgnoreCase(str));


    }
}