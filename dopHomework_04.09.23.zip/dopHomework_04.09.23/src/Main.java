import java.util.Random;

public class Main {
    public static void main(String[] args) {
    double a = Math.random();
    double b = Math.random();
        System.out.println("Первое число: " + a + " " + "Второе число: " +b);
       double q = Math.abs(a - b);
       double w = Math.min(a, b);
       double e = Math.max(a, b);
       double r = Math.pow(a, b*10);
       System.out.println("Вычитание: " + q);
       System.out.println("Минимум: " + w);
       System.out.println("Максимум: " + e);
       System.out.println("Степень: " + r);

    }
}