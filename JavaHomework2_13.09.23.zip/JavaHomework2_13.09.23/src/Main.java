import bebebe.Move;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sqr = new Scanner(System.in);
        Random rnd = new Random();
        int wins = 0;
        int losses = 0;

        System.out.println("Привет, давай сыграем в Камень, Ножницы, Бумага!!!");
        System.out.println("Выбери один из вариантов: \"rock\", \"paper\", \"scissors\" или \"N\" чтобы покинуть игру");

        do {
            System.out.println("-------------------------");
            System.out.print("Введи свой вариант: ");
            Move userMove = Move.valueOf(sqr.nextLine().toUpperCase(Locale.ROOT));

            int botChoise = rnd.nextInt(1, 4);
            Move choise = switch (botChoise) {
                case 1 -> Move.ROCK;
                case 2 -> Move.PAPER;
                default -> Move.SCISSORS;
            };
            System.out.println(choise);

            if (userMove == choise)
            System.out.println("Ничья!");
            else if (userMove == Move.ROCK && choise == Move.SCISSORS
            || userMove == Move.SCISSORS && choise == Move.PAPER || userMove == Move.PAPER && choise == Move.ROCK)
                System.out.println("Ты победил!" + " Количество побед: " + ++wins);
            else System.out.println("Ты проиграл!" + " Количество поражений: " + ++losses);



            System.out.println("Хотите продолжить игру Y/N?");
        } while (!"N".equalsIgnoreCase(sqr.nextLine()));
    }
}
