package bebebe;
public enum Move {
    ROCK,
    PAPER,
    SCISSORS;

}
