public class Main {
    public static void main(String[] args) {
    int chislo = 922;
    System.out.print("Число "+chislo+" -> "+chislo/100+","+chislo%100/10+","+chislo%10);
    }
}