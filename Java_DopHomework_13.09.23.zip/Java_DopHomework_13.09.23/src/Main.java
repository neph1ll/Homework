import month.Month;

import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите английское название любого месяца на ваш выбор:");
        Scanner sqr = new Scanner(System.in);
        String month = sqr.nextLine();
        Month user = Month.valueOf(month.toUpperCase(Locale.ROOT));

        String season = switch (user){
            case JANUARY, DECEMBER, FEBRUARY -> "Это один из месяцев Зимы!";
            case MARCH, APRIL, MAY -> "Это один из месяцев Весны!";
            case JUNE, JULY, AUGUST -> "Это один из месяцев Лета!";
            case SEPTEMBER, OCTOBER, NOVEMBER -> "Это один из месяцев Осени!";

        };
        System.out.println(season);
    }
}