import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Auto suzuki = new Auto("AUDI", "TT", 3.4, "газ", 400);
        System.out.println(suzuki);

        Auto mercedes = new Auto("Mercedes", "Maybach", 5.0, "Diesel", 500);
        System.out.println(mercedes);

        Auto bmv = new Auto("BMV", "X7", 5, ",Gas", 460);
        System.out.println(bmv);
        System.out.println();

        Auto[] auto = {suzuki, mercedes, bmv};
        Arrays.toString(auto);
        System.out.println(Arrays.toString(auto));
        
    }
}
