import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner sqr = new Scanner(System.in);
        System.out.print("Введите 1 целое число: ");
        int num1 = sqr.nextInt();
        System.out.print("Введите 2 целое число: ");
        int num2 = sqr.nextInt();
        int resNum1 = Math.abs(num1-10);
        int resNum2 = Math.abs(num2-10);
        if(resNum1<resNum2){
            System.out.println(num1);
        }
        else {
            System.out.println(num2);
        }
    }
}