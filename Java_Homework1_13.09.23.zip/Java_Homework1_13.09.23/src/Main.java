import Wedding.Wedding;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sqr = new Scanner(System.in);
        System.out.println("Привет, скажи сколько полных лет ты находишься в браке?");
        int brak = sqr.nextInt();
        Wedding nextWedding = Wedding.values()[brak];
        System.out.println("Поздравляю, у вас будет " + nextWedding + " в следующем году.");

    }
}