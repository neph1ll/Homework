package student;

public class University {
        Student oleksandr = new Student("Oleksandr");
}
