import java.util.Random;

public class Main {
    public static void main(String[] args) {
    int summa = 0;
    int a = 50;
    int b = 100;
    int c = 200;
    int d = 500;
    int newPC = 10000;
    Random rnd = new Random();

 while (newPC>summa){
     int rndChoise = rnd.nextInt(0,5);
     switch (rndChoise){
         case 1 -> summa+=a;
         case 2 -> summa+=b;
         case 3 -> summa+=c;
         default -> summa+=d;
     }
     System.out.println("Классно, я уже насобирал: " + summa + " мне осталось: " + (newPC-summa));
 }
        System.out.println("Ура, пойдёмте пить пиво!!!");

    }
}