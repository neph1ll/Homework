import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner scr = new Scanner(System.in);
        Random rnd = new Random();
        int flor = rnd.nextInt(-1,36);
        System.out.println("Лифт на " + flor + " этаже.");
        System.out.println("На каком этаже ты?");
        int userFlor = scr.nextInt();
        System.out.println("Ой, ты активировал функцию вызова, лифт уже едет");
        System.out.println("Посмотри на табло");
        do {
            if (flor>userFlor) {
                --flor;
                System.out.println(flor + " этаж");
            } else if (flor<userFlor) {
                ++flor;
                System.out.println(flor + " этаж");
            }
        } while (flor!=userFlor);
        System.out.println("Лифт прибыл");

    }
}