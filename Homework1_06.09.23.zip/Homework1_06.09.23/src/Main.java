import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sqr = new Scanner(System.in);
        System.out.print("Введите величину в метрах: ");
        float meter = sqr.nextFloat();
        System.out.println("Километров: " + meter/1000);
        System.out.println("Аршин: " + meter*1.406);
        System.out.println("Фут: " + meter*3.28);
        System.out.println("Миль: " + meter/1852);
    }
}