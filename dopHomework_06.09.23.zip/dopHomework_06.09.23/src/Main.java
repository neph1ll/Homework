public class Main {
    public static void main(String[] args) {
    int i = 6;
    int i2 = 4;
        System.out.println(i);
        System.out.println(i2);
    i += i2;
    i2 = i - i2;
    i -= i2;
        System.out.println(i);
        System.out.println(i2);


    }
}