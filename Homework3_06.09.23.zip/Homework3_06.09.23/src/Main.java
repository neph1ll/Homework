public class Main {
    public static void main(String[] args) {

        boolean isYearFinished = true;
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoast = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean hike = isYearFinished && (isGoodWeather || hasBoughtRaincoast) && (isJimFree ^ hasKateComeBack);
        System.out.println(hike);
    }
}